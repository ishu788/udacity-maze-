# Overview
These scripts and prefabs are deprecated.  They will be going away in an upcoming
release of the GoogleVR Unity SDK, since they will no longer be used once Unity has
native integration of the SDK.
